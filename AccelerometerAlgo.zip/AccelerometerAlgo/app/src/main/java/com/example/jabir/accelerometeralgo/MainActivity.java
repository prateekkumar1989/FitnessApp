package com.example.jabir.accelerometeralgo;

import android.content.Context;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.hardware.SensorManager;
import android.hardware.Sensor;
import android.hardware.SensorEventListener;
import android.hardware.SensorEvent;
import android.widget.TextView;
import java.util.*;
import java.math.*;

public class MainActivity extends ActionBarActivity implements SensorEventListener{

    private  SensorManager mSensorManager;
    private  Sensor mAccelerometer;
    private double lastUpdate = 0;
    private double offset=System.currentTimeMillis();
    private double last_accX=0, last_accY=0, last_accZ=0;
    private double last_velX=0,last_velY=0,last_velZ=0;
    private double accX=0,accY=0,accZ=0;
    private double velX=0,velY=0,velZ=0;
    private double AvgaccX=0,AvgaccY=0,AvgaccZ=0;
    int calibarationTime=0;
    private float resGravValues[]=new float[4];
    private double interTimeX,interTimeY,interTimeZ;
    private double interVelX,interVelY,interVelZ;
    boolean isInterX,isInterY,isInterZ;
    float ALPHA=0.25f;
    float Rmat[]=new float[16];
    float RmatInverted[]=new float[16];
    float Imat[]=new float[16];
    private double last_dis=0;
    double currentTime=0;
    boolean first=true;
    private List <Double> timestampsX=new ArrayList<Double>();
    private List<Double> timestampsY=new ArrayList<Double>();
    private List<Double> timestampsZ=new ArrayList<Double>();
    double coefficientBXStartToLast=0,coefficientAXStartToLast=0,coefficientCXStartToLast=0;
    double coefficientBYStartToLast=0,coefficientAYStartToLast=0,coefficientCYStartToLast=0;
    double coefficientBZStartToLast=0,coefficientAZStartToLast=0,coefficientCZStartToLast=0;
    private static final int SHAKE_THRESHOLD = 600;
    //private static readonly object _syncLock = new object();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        mAccelerometer = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        mSensorManager.registerListener(this, mAccelerometer , SensorManager.SENSOR_DELAY_NORMAL);

    }

    public void FindPointsVelocityChangingDirection()
    {
        /*if(isInterX)
        {
           if((last_velX>0&&interVelX<0)||(last_velX<0&&interVelX>0))
            {
                    double firstRoot=((-coefficientBXStartToLast)-Math.sqrt((coefficientBXStartToLast*coefficientBXStartToLast)-4*coefficientAXStartToLast*coefficientCXStartToLast))/(2*coefficientAXStartToLast);
                    double    secondRoot=((-coefficientBXStartToLast)+Math.sqrt((coefficientBXStartToLast*coefficientBXStartToLast)-4*coefficientAXStartToLast*coefficientCXStartToLast))/(2*coefficientAXStartToLast);
            }


        }
        else
        {*/
          //  if((last_velX>0&&velX<0)||(last_velX<0&&velX>0))
           // {
                if(((coefficientBXStartToLast*coefficientBXStartToLast) - 4 * coefficientAXStartToLast * coefficientCXStartToLast)>=0) {
                    double firstRoot = ((-coefficientBXStartToLast) - Math.sqrt((coefficientBXStartToLast * coefficientBXStartToLast) - 4 * coefficientAXStartToLast * coefficientCXStartToLast)) / (2 * coefficientAXStartToLast);
                    double secondRoot = ((-coefficientBXStartToLast) + Math.sqrt((coefficientBXStartToLast * coefficientBXStartToLast) - 4 * coefficientAXStartToLast * coefficientCXStartToLast)) / (2 * coefficientAXStartToLast);
                    if (firstRoot > lastUpdate/1000 && firstRoot < (currentTime)/1000)
                        timestampsX.add(firstRoot);
                    if (secondRoot > lastUpdate/1000 && secondRoot < (currentTime)/1000)
                        timestampsX.add(secondRoot);
                    Collections.sort(timestampsX);
                }
        //    }
         // }
        /*if(isInterY)
        {
            if((last_velX>0&&interVelX<0)||(last_velX<0&&interVelX>0))
            {

            }
        }
        else
        {*/
       // if((last_velY>0&&velY<0)||(last_velY<0&&velY>0))
       // {
        if(((coefficientBYStartToLast*coefficientBYStartToLast) - 4 * coefficientAYStartToLast * coefficientCYStartToLast)>=0) {
            double firstRootY = ((-coefficientBYStartToLast) - Math.sqrt((coefficientBYStartToLast * coefficientBYStartToLast) - 4 * coefficientAYStartToLast * coefficientCYStartToLast)) / (2 * coefficientAYStartToLast);
            double secondRootY = ((-coefficientBYStartToLast) + Math.sqrt((coefficientBYStartToLast * coefficientBYStartToLast) - 4 * coefficientAYStartToLast * coefficientCYStartToLast)) / (2 * coefficientAYStartToLast);
            if (firstRootY > lastUpdate/1000 && firstRootY < (currentTime)/1000)
                timestampsY.add(firstRootY);
            if (secondRootY > lastUpdate/1000 && secondRootY < (currentTime)/1000)
                timestampsY.add(secondRootY);
            Collections.sort(timestampsY);
        }
      //  }
       // }
        /*if(isInterZ)
        {
            if((last_velX>0&&interVelX<0)||(last_velX<0&&interVelX>0))
            {

            }
        }
        else
        {*/
       // if((last_velZ>0&&velZ<0)||(last_velZ<0&&velZ>0))
       // {
            if(((coefficientBZStartToLast*coefficientBZStartToLast) - 4 * coefficientAZStartToLast * coefficientCZStartToLast)>=0)
        {
            double firstRootZ = ((-coefficientBZStartToLast) - Math.sqrt((coefficientBZStartToLast * coefficientBZStartToLast) - 4 * coefficientAZStartToLast * coefficientCZStartToLast)) / (2 * coefficientAZStartToLast);
            double secondRootZ = ((-coefficientBZStartToLast) + Math.sqrt((coefficientBZStartToLast * coefficientBZStartToLast) - 4 * coefficientAZStartToLast * coefficientCZStartToLast)) / (2 * coefficientAZStartToLast);
            if (firstRootZ > lastUpdate/1000 && firstRootZ < (currentTime)/1000)
                timestampsZ.add(firstRootZ);
            if (secondRootZ > lastUpdate/1000 && secondRootZ < (currentTime)/1000)
                timestampsZ.add(secondRootZ);
            Collections.sort(timestampsZ);
        }
       // }
        FindNextTimeInstance();
    }

    public void CalculateDistance(double start,double end)
    {
       /* if(isInterX)
        {
            if(start<interTimeX)
            {
                if(end<interTimeX)
                {

                }
                else
                {

                }
            }
            else
            {

            }
        }
        else
        {*/
            double disXUpLimit=((coefficientAXStartToLast*end*end*end)/3)+((coefficientBXStartToLast*end*end)/2)+coefficientCXStartToLast*end;
            double disXLowerLimit=((coefficientAXStartToLast*start*start*start)/3)+((coefficientBXStartToLast*start*start)/2)+coefficientCXStartToLast*start;
            double disX=Math.abs(disXUpLimit-disXLowerLimit);
        //}

       /* if(isInterY)
        {
            if(start<interTimeY)
            {
                if(end<interTimeY)
                {

                }
                else
                {

                }
            }
            else
            {

            }
        }
        else
        {*/
            double disYUpLimit=((coefficientAYStartToLast*end*end*end)/3)+((coefficientBYStartToLast*end*end)/2)+coefficientCYStartToLast*end;
            double disYLowerLimit=((coefficientAYStartToLast*start*start*start)/3)+((coefficientBYStartToLast*start*start)/2)+coefficientCYStartToLast*start;
            double disY=Math.abs(disYUpLimit-disYLowerLimit);
        //}

        /*if(isInterZ)
        {
            if(start<interTimeZ)
            {
                if(end<interTimeZ)
                {

                }
                else
                {

                }
            }
            else
            {

            }
        }
        else
        {*/
            double disZUpLimit=((coefficientAZStartToLast*end*end*end)/3)+((coefficientBZStartToLast*end*end)/2)+coefficientCZStartToLast*end;
            double disZLowerLimit=((coefficientAZStartToLast*start*start*start)/3)+((coefficientBZStartToLast*start*start)/2)+coefficientCZStartToLast*start;
            double disZ=Math.abs(disZUpLimit-disZLowerLimit);
       // }
        TextView tv = (TextView)findViewById(R.id.TextView_Message);
        last_dis=last_dis+Math.sqrt((disX*disX)+(disY*disY)+(disZ*disZ));
        //double n=1.455;
        //last_dis=last_dis+Math.sqrt(disZUpLimit);
        tv.setText("X dis"+disX+"Y dis"+disY+"Z dis"+disZ+"Total Distance"+" "+last_dis);


    }
    public void FindNextTimeInstance()
    {
      int i=0,j=0,k=0;
      double start=lastUpdate/1000;
      while(i<timestampsX.size()||j<timestampsY.size()||k<timestampsZ.size())
      {
           if(i!=timestampsX.size()&&(j==timestampsY.size()||timestampsX.get(i)<=timestampsY.get(j)))
           {
               if(k==timestampsZ.size()||timestampsX.get(i)<=timestampsZ.get(k))
               {
                  //X timestamp
                   CalculateDistance( start, timestampsX.get(i));
                   start=timestampsX.get(i);
                   i++;
               }
               else
               {
                   //Z timestamp
                   CalculateDistance( start, timestampsZ.get(k));
                   start=timestampsZ.get(k);
                   k++;
               }

           }
          else
           {

               if (j == timestampsY.size())
               {
                  //Z timestamp
                   CalculateDistance( start, timestampsZ.get(k));
                   start=timestampsZ.get(k);
                   k++;
               }
               else
               {
                   if(k==timestampsZ.size()||timestampsY.get(j)<=timestampsZ.get(k))
                   {
                       //Y timestamp
                       CalculateDistance( start, timestampsY.get(j));
                       start=timestampsY.get(j);
                       j++;
                   }
                   else
                   {
                       //Z timestamp
                       CalculateDistance( start, timestampsZ.get(k));
                       start=timestampsZ.get(k);
                       k++;
                   }
               }
           }
      }
        TextView tv = (TextView)findViewById(R.id.TextView_Message);
        //tv.setText("time"+currentTime);
        CalculateDistance(start, currentTime / 1000);
        last_velX=velX;
        last_velY=velY;
        last_velZ=velZ;
        last_accX=accX;
        last_accY=accY;
        last_accZ=accZ;
        timestampsX.clear();
        timestampsY.clear();
        timestampsZ.clear();

    }

    public void InterpretDistance(/*double velX,double interVelX,double velY,double interVelY,double velZ,double interVelZ,double interTimeX,double interTimeY,double interTimeZ,boolean isInterX,boolean isInterY,boolean isInterZ*/)
    {
       /* if(isInterX)
        {
            double coefficientAXInter = (0 - last_accX) / (2 * (interTimeX - lastUpdate));
            double coefficientBXInter = -(2 * coefficientAXInter * interTimeX);
            double coefficientCXInter = last_velX - (coefficientAXInter * lastUpdate * lastUpdate + coefficientBXInter * lastUpdate);
            double coefficientAXInterToLast = (accX) / (2 * (lastUpdate + 100 - interTimeX));
            double coefficientBXInterToLast = -(2 * coefficientAXInterToLast * (interTimeX));
            double coefficientCXInterToLast = interVelX - (coefficientAXInterToLast * interTimeX * interTimeX + coefficientBXInterToLast * interTimeX);
        }
        else
        {*/
              coefficientAXStartToLast=(accX-last_accX)/(2*(currentTime-lastUpdate)/1000);
              coefficientBXStartToLast=last_accX-(2*coefficientAXStartToLast*(lastUpdate/1000));
              coefficientCXStartToLast=last_velX-((coefficientAXStartToLast*lastUpdate/1000*lastUpdate/1000)+(coefficientBXStartToLast*lastUpdate/1000));

        //}

       /* if(isInterY)
        {
            double coefficientAYInter = (0 - last_accY) / (2 * (interTimeY - lastUpdate));
            double coefficientBYInter = -(2 * coefficientAYInter * interTimeY);
            double coefficientCYInter = last_velX - (coefficientAYInter * lastUpdate * lastUpdate + coefficientBYInter * lastUpdate);

            double coefficientAYInterToLast = (accY) / (2 * (lastUpdate + 100 - interTimeY));
            double coefficientBYInterToLast = -(2 * coefficientAYInterToLast * (interTimeY));
            double coefficientCYInterToLast = interVelY - (coefficientAYInterToLast * interTimeY * interTimeY + coefficientBYInterToLast * interTimeY);
        }
        else
        {*/
             coefficientAYStartToLast=(accY-last_accY)/(2*(currentTime-lastUpdate)/1000);
             coefficientBYStartToLast=last_accY-(2*coefficientAYStartToLast*(lastUpdate/1000));
             coefficientCYStartToLast=last_velY-((coefficientAYStartToLast*lastUpdate/1000*lastUpdate/1000)+(coefficientBYStartToLast*lastUpdate/1000));
        //}

      /*  if(isInterZ)
        {
            double coefficientAZInter = (0 - last_accZ) / (2 * (interTimeZ - lastUpdate));
            double coefficientBZInter = -(2 * coefficientAZInter * interTimeZ);
            double coefficientCZInter = last_velX - (coefficientAZInter * lastUpdate * lastUpdate + coefficientBZInter * lastUpdate);

            double coefficientAZInterToLast = (accZ) / (2 * (lastUpdate + 100 - interTimeZ));
            double coefficientBZInterToLast = -(2 * coefficientAZInterToLast * (interTimeZ));
            double coefficientCZInterToLast = interVelZ - (coefficientAZInterToLast * interTimeZ * interTimeZ + coefficientBZInterToLast * interTimeZ);
        }
        else
        {*/
             coefficientAZStartToLast=(accZ-last_accZ)/(2*(currentTime-lastUpdate)/1000);
             coefficientBZStartToLast=last_accZ-(2*coefficientAZStartToLast*(lastUpdate/1000));
             coefficientCZStartToLast=last_velZ-((coefficientAZStartToLast*lastUpdate/1000*lastUpdate/1000)+(coefficientBZStartToLast*lastUpdate/1000));
        //}
        /*double coefficientAXInterToLast=(accX)/(2*(lastUpdate+100-interTimeX));
        double coefficientBXInterToLast=-(2*coefficientAXInterToLast*(interTimeX));
        double coefficientCXInterToLast=interVelX-(coefficientAXInter*interTimeX*interTimeX+coefficientBXInter*interTimeX);

        double coefficientAYInterToLast=(accY)/(2*(lastUpdate+100-interTimeY));
        double coefficientBYInterToLast=-(2*coefficientAYInter*(interTimeY));
        double coefficientCYInterToLast=interVelY-(coefficientAYInter*interTimeY*interTimeY+coefficientBYInter*interTimeY);

        double coefficientAZInterToLast=(accZ)/(2*(lastUpdate+100-interTimeZ));
        double coefficientBZInterToLast=-(2*coefficientAZInter*(interTimeZ));
        double coefficientCZInterToLast=interVelZ-(coefficientAZInter*interTimeZ*interTimeZ+coefficientBZInter*interTimeZ);*/
        FindPointsVelocityChangingDirection();
    }
    public void InterpretVelocity(/*double interTimeX,double interTimeY,double interTimeZ*/)
    {
       /*double interVelX=0;
       double interVelY=0;
       double interVelZ=0;
       if(interTimeX!=0)
       {
         interVelX=0.5*last_accX*interTimeX+last_velX;
       }

        if(interTimeY!=0)
        {
            interVelY=0.5*last_accY*interTimeY+last_velY;
        }
        if(interTimeZ!=0)
        {
            interVelZ=0.5*last_accZ*interTimeZ+last_velZ;
        }*/
        velX=0.5*0.1*(accX+last_accX)+last_velX;
        velY=0.5*0.1*(accY+last_accY)+last_velY;
        velZ=0.5*0.1*(accZ+last_accZ)+last_velZ;
        InterpretDistance();

    }

    protected float[] lowPass( float[] input, float[] output )
    {
        if ( output == null ) return input;
        for ( int i=0; i<input.length; i++ ) {
            output[i] = output[i] + ALPHA * (input[i] - output[i]);
        }
        return output;
    }
    public void onSensorChanged(SensorEvent sensorEvent)
    {
        Sensor mySensor = sensorEvent.sensor;
        float gravSensorVals[]=new float[4],magSensorVals[]=new float[4],gravSensorVals1[]=new float[3];
        if (sensorEvent.sensor.getType() == Sensor.TYPE_ACCELEROMETER)
        {
            gravSensorVals1 =lowPass(sensorEvent.values.clone(), sensorEvent.values);
        }
        else if (sensorEvent.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD)
        {
            magSensorVals = lowPass(sensorEvent.values.clone(), sensorEvent.values);
        }
        TextView tv = (TextView)findViewById(R.id.TextView_Message);
       // tv.setText("AccX"+" "+gravSensorVals1[2]);
   /*     if (gravSensorVals != null && magSensorVals != null)
        {
            SensorManager.getRotationMatrix(R, I, gravSensorVals, magSensorVals);

            int rotation = Compatibility.getRotation(this);
            if (rotation == 1) {
                SensorManager.remapCoordinateSystem(RTmp, SensorManager.AXIS_X, SensorManager.AXIS_MINUS_Z, Rot);
            } else {
                SensorManager.remapCoordinateSystem(RTmp, SensorManager.AXIS_Y, SensorManager.AXIS_MINUS_Z, Rot);
            }
        }*/
        /*for(int i=0;i<3;i++)
            gravSensorVals[i]=gravSensorVals1[i];
        gravSensorVals[3]=-1;
        SensorManager.getRotationMatrix(Rmat, Imat, gravSensorVals, magSensorVals);
        android.opengl.Matrix.invertM(Rmat,0,RmatInverted,0);
        android.opengl.Matrix.multiplyMV(gravSensorVals,0,gravSensorVals,0,RmatInverted,0);
       // android.opengl.Matrix.multiplyMV()
        TextView tv = (TextView)findViewById(R.id.TextView_Message);
        // tv.setText("AccX"+" "+resGravValues[0]+"Accy"+" "+resGravValues[1]+"AccZ"+" "+resGravValues[2]);
        //tv.setText("AccX"+" "+gravSensorVals[0]+"Accy"+" "+gravSensorVals[1]+"AccZ"+" "+gravSensorVals[2]);
       //tv.setText("AccX"+gravSensorVals[3]);
        */
        if (mySensor.getType() == Sensor.TYPE_ACCELEROMETER)
        {
            if((System.currentTimeMillis()-offset)-(lastUpdate)>100)
            {

                 currentTime=System.currentTimeMillis()-offset;
                 accX = gravSensorVals1[0];
                 accY = gravSensorVals1[1];
                 accZ = gravSensorVals1[2];
                if(calibarationTime<10)
                {
                    AvgaccX=(AvgaccX*calibarationTime+accX)/(calibarationTime+1);
                    AvgaccY=(AvgaccY*calibarationTime+accY)/(calibarationTime+1);
                    AvgaccZ=(AvgaccZ*calibarationTime+accZ)/(calibarationTime+1);
                    calibarationTime++;
                }
                else
                {
                    accX=gravSensorVals1[0]-AvgaccX;
                    accY=gravSensorVals1[1]-AvgaccY;
                    accZ=gravSensorVals1[2]-AvgaccZ;
                    InterpretVelocity();
                    //.setText("AccX"+" "+accX+"AccY"+" "+accY+" "+"AccZ"+" "+accZ);
                }
                //tv.setText("AccX"+" "+accX+"AccY"+" "+accY+" "+"AccZ"+" "+accZ);
                lastUpdate=currentTime;

                /*if(last_accX<0&&accX>0)
                {
                    double interTimeX = 0.1 / (1 + accX / last_accX);
                }
                if(last_accY<0&&accY>0)
                {
                    double interTimeY=0.1/(1+accY/last_accY);
                }
                if(last_accZ<0&&accZ>0)
                {
                    double interTimeZ=0.1/(1+accZ/last_accZ);
                }*/
               // TextView tv = (TextView)findViewById(R.id.TextView_Message);
               // tv.setText("AccX"+accX+" "+"AccY"+accY+" "+"AccZ"+accZ+"TotalDistance"+last_dis+"A coefficient"+" "+coefficientAXStartToLast+"B coefficient"+" "+coefficientBXStartToLast+"C coefficient"+" "+coefficientCXStartToLast+"last acc X"+last_accX+"last update"+lastUpdate+"currentTime"+currentTime);


            }
        }
    }

    public void onAccuracyChanged(Sensor sensor, int accuracy)
    {

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
