package cs4222.nus.accelerometer;

/*
This uses an implementation of a linear Kalman filter which is an estimator that converges to the true value over time.
We've used for a standard threshold algorithm to do step detection and is similar to the one at
http://stackoverflow.com/questions/4993993/how-to-detect-walking-with-android-accelerometer. In addition, we have also
implemented a smoothing average low-pass filter which gives comparable performance and can be optionally used as well.

Our own implementations which are either commented out here or are in a separate project folder include:
* Double Integration of the acceleration components relative to inertial system to calculate distance - gives too much error to be usable.
* Self implementation of the Kalman Filter which does not give results as consistent as the one used below.

*/

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Environment;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import java.io.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.OutputStreamWriter;
import java.util.ArrayList;


public class AccelerometerMainActivity extends ActionBarActivity implements SensorEventListener, AdapterView.OnItemSelectedListener {


    final float 	STEP_ACCELERATION_THRESHOLD	= 1; //0.05f for local KF
    final int 		INACTIVITY_THRESHOLD	= 10;
    int		    NO_MOVEMENT 	= 0;
    int 		FORWARD_LEG	= 1;
    int 		BACKWARD_LEG 	= 2;
    final int 		LEG_SENSOR_RATE		= 60000; //SensorManager.SENSOR_DELAY_UI;

    float LastZ;
    int LastActivity = NO_MOVEMENT;
    int InactivityCount = 0;
    KalmanFilter TripleFilters[] = new KalmanFilter[3];
    int steps;
    String filter;

    private Spinner spinner;
    private static final String[]paths = {"Kalman Filter", "Low Pass Filter"};

    SensorManager sensorManager;
    boolean color = false;
    View view;
    long lastUpdate;
    TextView currentX, currentY, currentZ, currentA;
    float a = 0.4f;
    float z = SensorManager.GRAVITY_EARTH;
    float LowPassX, LowPassY, LowPassZ, lowPassG;
    File myFile;
    public PrintWriter LogFileOut;
    public PrintWriter locationLogFileOut;
    private float u=0, d=0;
    EditText cd;
    int calibrationdistance;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accelerometer_main);

        spinner = (Spinner)findViewById(R.id.spinner);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(AccelerometerMainActivity.this,
                android.R.layout.simple_spinner_item,paths);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);

        //cd = (EditText) findViewById(R.id.calibrationdistance);

        currentX = (TextView) findViewById(R.id.currentX);
        currentY = (TextView) findViewById(R.id.currentY);
        currentZ = (TextView) findViewById(R.id.currentZ);
        currentA = (TextView) findViewById(R.id.currentA);

        try {
            openLogFiles();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_accelerometer_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() != Sensor.TYPE_ACCELEROMETER){
            return;
        }
        //getAccelerometer(event);

        float[] values = event.values;
        if(filter == "lowpassfilter")
            z = lowPass(values[2],z);
        else if(filter == "kalmanfilter")
            z = filter(values[2]);
        System.out.println(filter + " z = " + z);

        if (Math.abs(z - LastZ) > STEP_ACCELERATION_THRESHOLD)
        {
            InactivityCount = 0;
            int currentActivity = (z > LastZ) ? FORWARD_LEG : BACKWARD_LEG;
            if (currentActivity != LastActivity)
            {
                LastActivity = currentActivity;
                currentX.setText("Walking"); steps++;
                currentY.setText(Integer.toString(steps/2));
            }
        }
        else
        {
            if (InactivityCount > INACTIVITY_THRESHOLD)
            {
                if (LastActivity != NO_MOVEMENT)
                {
                    LastActivity = NO_MOVEMENT;
                    currentX.setText("Idling");
                }
            }
            else InactivityCount++;
        }
        LastZ = z;

        /*
        // Movement
        float xa = values[0];
        float ya = values[1];
        float za = Math.abs(values[2])-Math.abs(SensorManager.GRAVITY_EARTH);

        float a = (float) ( Math.sqrt( ( xa * xa + ya * ya + za * za) ) );
        long actualTime = System.currentTimeMillis();
        if (actualTime - lastUpdate < 200)
        {
            return;
        }
        float dt = (actualTime - lastUpdate)/1000;
        lastUpdate = actualTime;

        d += (float) (u*dt + 0.5*a*dt*dt);
        currentA.setText(Float.toString(d));
        u = u*dt;
        */
    }


    float filter(float measurement){
        float f1 = TripleFilters[0].correct(measurement);
        float f2 = TripleFilters[1].correct(f1);
        float f3 = TripleFilters[2].correct(f2);

        return f3;
    }

    private void getAccelerometer(SensorEvent event) {

        float[] values = event.values;


        // Movement
        float x = values[0];
        float y = values[1];
        float z = values[2];

        float g =  ( x * x + y * y + z * z) / (SensorManager.GRAVITY_EARTH * SensorManager.GRAVITY_EARTH) ;
        long actualTime = System.currentTimeMillis();
        if (actualTime - lastUpdate < 200)
        {
            return;
        }
        lastUpdate = actualTime;

        LowPassX = lowPass(x,LowPassX);
        LowPassY = lowPass(y,LowPassY);
        LowPassZ = lowPass(z,LowPassZ);
        lowPassG = lowPass(g,lowPassG);

        logReading(LowPassX, LowPassY, LowPassZ, lowPassG);

        currentX.setText(Float.toString(x));
        currentY.setText(Float.toString(y));
        currentZ.setText(Float.toString(z));
        currentA.setText(Double.toString(Math.round(g)));
    }



    public void startbutton(View view) {

        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        lastUpdate = System.currentTimeMillis();
        TripleFilters[0] = new KalmanFilter(1, 1, 0.01f, 0.0025f);
        TripleFilters[1] = new KalmanFilter(1, 1, 0.01f, 0.0025f);
        TripleFilters[2] = new KalmanFilter(1, 1, 0.01f, 0.0025f);

        steps = 0; LastZ = z = 0;
        sensorManager.registerListener(this,
                sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
                LEG_SENSOR_RATE);
    }
/*
    public void calibrationstart(View view) {

    }

    public void calibrationend(View view) {

    }
*/
    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    protected void onPause() {
        // unregister listener
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    float lowPass(float current, float last)
    {
        /* This is a standard implementation from http://www.wrox.com/WileyCDA/WroxTitle/Professional-Android-Sensor-Programming.productCd-1118183487.html */
        return last*(1.0f - a) + current*a;
    }



    /** Helper method to make the log files ready for writing. */
    public void openLogFiles()
            throws IOException {

        // First, check if the sdcard is available for writing
        String externalStorageState = Environment.getExternalStorageState();
        if ( ! externalStorageState.equals ( Environment.MEDIA_MOUNTED ) &&
                ! externalStorageState.equals ( Environment.MEDIA_SHARED ) )
            throw new IOException ( "sdcard is not mounted on the filesystem" );

        // Second, create the log directory
        File logDirectory = new File( Environment.getExternalStorageDirectory() ,
                "PA1" );
        logDirectory.mkdirs();
        if ( ! logDirectory.isDirectory() )
            throw new IOException( "Unable to create log directory" );

        // Third, create output streams for the log files (APPEND MODE)
        // Barometer log
        File logFile = new File( logDirectory , "Accelerometer.csv" );
        FileOutputStream fout = new FileOutputStream( logFile , true );
        LogFileOut = new PrintWriter( fout );
    }

    /** Helper method that closes the log files. */
    public void closeLogFiles() {

        // Close the log file
        try {
            LogFileOut.close();
        }
        catch ( Exception e ) {

        }
        finally {
            LogFileOut = null;
        }
    }

    /** Helper method that logs the barometer reading. */
    private void logReading( float x, float y, float z, float g ) {

        // Barometer details
        final StringBuilder sb = new StringBuilder();
        sb.append( x + "," );
        sb.append( y + "," );
        sb.append( z + "," );
        sb.append( g );
        //System.out.println("hello");
        // Log to the file (and flush)
        LogFileOut.println(sb.toString());
        LogFileOut.flush();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        try {

            // Close the log files
            closeLogFiles();
        }
        catch ( Exception e ) {

        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        switch (position) {
            case 0:
                filter = "kalmanfilter";
                break;
            case 1:
                filter = "lowpassfilter";
                break;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
